import 'dart:async';
import 'dart:math';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

const green = Color(0xFF65C98A);
const darkGreen = Color(0xFF32966B);
const cream = Color(0xFFFFF9EC);
const ink = Color(0xFF34433C);
const muted = Color(0xFF87958D);
const gold = Color(0xFFFFC857);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  var firebaseReady = false;
  try {
    // Add generated firebase_options.dart via `flutterfire configure` for real cloud accounts.
    await Firebase.initializeApp();
    firebaseReady = true;
  } catch (_) {
    // The app remains usable in local-only mode until Firebase is configured.
  }
  runApp(GachaIslandApp(firebaseReady: firebaseReady));
}

class GachaIslandApp extends StatelessWidget {
  final bool firebaseReady;
  const GachaIslandApp({super.key, required this.firebaseReady});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: '扭蛋小島',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFFF4F7F0),
      colorScheme: ColorScheme.fromSeed(seedColor: green, primary: darkGreen, secondary: gold),
      fontFamily: 'Arial',
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF4F7F0), foregroundColor: ink, elevation: 0),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
    ),
    home: AppShell(firebaseReady: firebaseReady),
  );
}

class Pet {
  final String id, emoji, name, quote;
  final int rarity;
  const Pet(this.id, this.emoji, this.name, this.rarity, this.quote);
  Map<String, dynamic> toJson() => {'id':id,'emoji':emoji,'name':name,'rarity':rarity,'quote':quote};
  factory Pet.fromJson(Map<String,dynamic> j) => Pet(j['id'],j['emoji'],j['name'],j['rarity'] ?? 0,j['quote'] ?? '今天也要開心！');
}

const basePets = <Pet>[
  Pet('cat','🐱','小貓',0,'今天也要曬太陽！'), Pet('dog','🐶','小狗',0,'汪！你最棒了！'),
  Pet('rabbit','🐰','兔兔',0,'蹦蹦跳跳～'), Pet('hamster','🐹','倉鼠',0,'小小努力也很棒。'),
  Pet('chick','🐥','小雞',0,'啾啾！休息一下吧。'), Pet('frog','🐸','青蛙',0,'呱～慢慢來。'),
  Pet('fox','🦊','狐狸',1,'聰明地完成今天！'), Pet('panda','🐼','熊貓',1,'抱抱自己。'),
  Pet('owl','🦉','貓頭鷹',1,'知識正在累積。'), Pet('penguin','🐧','企鵝',1,'一起往前走！'),
  Pet('unicorn','🦄','獨角獸',2,'奇蹟也會發生。'), Pet('dragon','🐉','小龍',2,'今天也閃閃發光！'),
];

class HabitTask {
  String id, name, type, app, link;
  double target, progress;
  int reward;
  bool done;
  String paidDay;
  HabitTask({required this.id,required this.name,required this.type,required this.target,required this.reward,this.app='',this.link='',this.progress=0,this.done=false,this.paidDay=''});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'type':type,'target':target,'reward':reward,'app':app,'link':link,'progress':progress,'done':done,'paidDay':paidDay};
  factory HabitTask.fromJson(Map<String,dynamic> j)=>HabitTask(id:j['id'],name:j['name'],type:j['type']??'check',target:(j['target']??1).toDouble(),reward:j['reward']??1,app:j['app']??'',link:j['link']??'',progress:(j['progress']??0).toDouble(),done:j['done']??false,paidDay:j['paidDay']??'');
}

class IslandState extends ChangeNotifier {
  int coins = 3;
  int coinCap = 20;
  int gachaCost = 5;
  String day = _today();
  bool sound = true;
  bool dark = false;
  final List<HabitTask> tasks = [];
  final List<Pet> customPets = [];
  final List<String> owned = [];
  bool get hasTasks => tasks.isNotEmpty;
  List<Pet> get pets => [...basePets, ...customPets];
  int get completed => tasks.where((t)=>t.done).length;

  IslandState() {
    tasks.addAll([
      HabitTask(id:'water',name:'喝水 2000cc',type:'check',target:1,reward:1),
      HabitTask(id:'english',name:'學英文',type:'minutes',target:15,reward:2,app:'語言學習'),
      HabitTask(id:'move',name:'運動',type:'minutes',target:30,reward:2,app:'健康'),
    ]);
    load();
  }

  static String _today()=>DateTime.now().toIso8601String().substring(0,10);
  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    final raw=p.getString('island_state_v1');
    if(raw!=null){
      try {
        final j=Map<String,dynamic>.from(Uri.decodeComponent(raw).isEmpty?{}:const _JsonDecoder().decode(Uri.decodeComponent(raw)));
        coins=j['coins']??3; coinCap=j['coinCap']??20; gachaCost=j['gachaCost']??5;
        day=j['day']??_today(); sound=j['sound']??true; dark=j['dark']??false;
        tasks..clear()..addAll((j['tasks'] as List? ?? []).map((x)=>HabitTask.fromJson(Map<String,dynamic>.from(x))));
        customPets..clear()..addAll((j['customPets'] as List? ?? []).map((x)=>Pet.fromJson(Map<String,dynamic>.from(x))));
        owned..clear()..addAll(List<String>.from(j['owned']??[]));
      } catch (_) {}
    }
    rollover(); notifyListeners();
  }
  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    final j={'coins':coins,'coinCap':coinCap,'gachaCost':gachaCost,'day':day,'sound':sound,'dark':dark,'tasks':tasks.map((x)=>x.toJson()).toList(),'customPets':customPets.map((x)=>x.toJson()).toList(),'owned':owned};
    await p.setString('island_state_v1',Uri.encodeComponent(_JsonEncoder().convert(j)));
    notifyListeners();
  }
  void rollover(){
    if(day!=_today()){day=_today();for(final t in tasks){t.done=false;t.progress=0;}save();}
  }
  void addTask(String name,String type,double target,int reward,String app,String link){
    tasks.add(HabitTask(id:DateTime.now().microsecondsSinceEpoch.toString(),name:name,type:type,target:target,reward:reward,app:app,link:link));save();
  }
  void complete(HabitTask t,bool value){
    t.done=value;
    if(value && t.paidDay!=_today()){
      t.paidDay=_today();
      coins=min(coinCap,coins+t.reward);
    }
    save();
  }
  void updateProgress(HabitTask t,double v){
    t.progress=v;
    if(v>=t.target && !t.done) complete(t,true); else save();
  }
  Pet? draw(){
    if(coins<gachaCost)return null;
    coins-=gachaCost;
    final r=Random().nextDouble();
    final rarity=r<.70?0:r<.95?1:2;
    var pool=pets.where((p)=>p.rarity==rarity).toList();
    if(pool.isEmpty)pool=pets;
    final pet=pool[Random().nextInt(pool.length)];
    owned.add(pet.id); save(); return pet;
  }
  void addPet(String emoji,String name,int rarity,String quote){
    customPets.add(Pet('custom_${DateTime.now().microsecondsSinceEpoch}',emoji,name,rarity,quote.isEmpty?'我是你的專屬夥伴！':quote));save();
  }
  int count(String id)=>owned.where((x)=>x==id).length;
}

class _JsonDecoder { const _JsonDecoder(); dynamic decode(String s)=>_decode(s); }
class _JsonEncoder { dynamic convert(Object? o)=>_encode(o); }
dynamic _decode(String s) { // small JSON bridge; uses dart:convert through helper below
  return jsonDecode(s);
}
String _encode(Object? o)=>jsonEncode(o);

class AuthService {
  final FirebaseAuth? auth;
  final FirebaseFirestore? db;
  AuthService(bool ready):auth(ready?FirebaseAuth.instance:null),db(ready?FirebaseFirestore.instance:null);
  User? get user=>auth?.currentUser;
  Future<void> google() async {
    if(auth==null)throw Exception('尚未設定 Firebase');
    final account=await GoogleSignIn().signIn();
    if(account==null)return;
    final token=await account.authentication;
    final credential=GoogleAuthProvider.credential(accessToken:token.accessToken,idToken:token.idToken);
    await auth!.signInWithCredential(credential);
  }
  Future<void> apple() async {
    if(auth==null)throw Exception('尚未設定 Firebase');
    final provider=OAuthProvider('apple.com');
    if(Platform.isAndroid) {
      // Android uses Firebase's browser-based OAuth flow for Apple ID.
      await auth!.signInWithProvider(provider);
    } else {
      final c=await SignInWithApple.getAppleIDCredential(scopes:[AppleIDAuthorizationScopes.email,AppleIDAuthorizationScopes.fullName]);
      final oauth=provider.credential(idToken:c.identityToken,accessToken:c.authorizationCode);
      await auth!.signInWithCredential(oauth);
    }
  }
  Future<void> sync(IslandState s) async {
    final u=user;if(u==null||db==null)return;
    await db!.collection('users').doc(u.uid).set({
      'coins':s.coins,'coinCap':s.coinCap,'gachaCost':s.gachaCost,'day':s.day,
      'tasks':s.tasks.map((x)=>x.toJson()).toList(),'customPets':s.customPets.map((x)=>x.toJson()).toList(),'owned':s.owned,
      'updatedAt':FieldValue.serverTimestamp()
    },SetOptions(merge:true));
  }
  Future<void> restore(IslandState s) async {
    final u=user;if(u==null||db==null)return;
    final d=await db!.collection('users').doc(u.uid).get();if(!d.exists)return;
    final j=d.data()!;
    s.coins=j['coins']??s.coins;s.coinCap=j['coinCap']??s.coinCap;s.gachaCost=j['gachaCost']??s.gachaCost;
    s.tasks..clear()..addAll((j['tasks'] as List? ?? []).map((x)=>HabitTask.fromJson(Map<String,dynamic>.from(x))));
    s.customPets..clear()..addAll((j['customPets'] as List? ?? []).map((x)=>Pet.fromJson(Map<String,dynamic>.from(x))));
    s.owned..clear()..addAll(List<String>.from(j['owned']??[]));s.save();
  }
  Future<void> signOut()=>auth?.signOut()??Future.value();
}

class AppShell extends StatefulWidget {
  final bool firebaseReady;
  const AppShell({super.key,required this.firebaseReady});
  @override State<AppShell> createState()=>_AppShellState();
}
class _AppShellState extends State<AppShell> {
  late final IslandState state;
  late final AuthService auth;
  int tab=0;
  Pet? lastPet;
  @override void initState(){super.initState();state=IslandState();auth=AuthService(widget.firebaseReady);}
  @override void dispose(){state.dispose();super.dispose();}
  void message(String s){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s),behavior:SnackBarBehavior.floating));}
  @override Widget build(BuildContext context){
    return AnimatedBuilder(animation:state,builder:(context,_){
      final pages=[
        IslandPage(state:state,onTasks:()=>setState(()=>tab=1)),
        TasksPage(state:state),
        GachaPage(state:state,onDraw:(p)=>setState(()=>lastPet=p)),
        CollectionPage(state:state),
        ProfilePage(state:state,auth:auth,firebaseReady:widget.firebaseReady,onMessage:message),
      ];
      return Theme(data:Theme.of(context).copyWith(brightness:state.dark?Brightness.dark:Brightness.light,scaffoldBackgroundColor:state.dark?const Color(0xFF18251F):const Color(0xFFF4F7F0),colorScheme:ColorScheme.fromSeed(seedColor:green,brightness:state.dark?Brightness.dark:Brightness.light)),child:Scaffold(
        appBar:AppBar(title:const Text('🐾 扭蛋小島',style:TextStyle(fontWeight:FontWeight.w900)),actions:[
          Padding(padding:const EdgeInsets.symmetric(horizontal:8),child:Center(child:CoinPill(coins:state.coins,cap:state.coinCap))),
          IconButton(onPressed:()=>setState(()=>state.dark=!state.dark),icon:Icon(state.dark?Icons.light_mode:Icons.dark_mode)),
        ]),
        body:SafeArea(child:IndexedStack(index:tab,children:pages)),
        bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[
          NavigationDestination(icon:Icon(Icons.terrain_outlined),selectedIcon:Icon(Icons.terrain),label:'小島'),
          NavigationDestination(icon:Icon(Icons.check_circle_outline),label:'任務'),
          NavigationDestination(icon:Icon(Icons.catching_pokemon_outlined),label:'扭蛋'),
          NavigationDestination(icon:Icon(Icons.collections_bookmark_outlined),label:'圖鑑'),
          NavigationDestination(icon:Icon(Icons.person_outline),label:'我的'),
        ]),
      ));
    });
  }
}

class CoinPill extends StatelessWidget {
  final int coins,cap;const CoinPill({super.key,required this.coins,required this.cap});
  @override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),decoration:BoxDecoration(color:const Color(0xFFFFF0C2),borderRadius:BorderRadius.circular(30)),child:Text('🪙 $coins/$cap',style:const TextStyle(color:Color(0xFF76551B),fontWeight:FontWeight.w900)));
}
class PagePad extends StatelessWidget {final Widget child;const PagePad({super.key,required this.child});@override Widget build(BuildContext c)=>SingleChildScrollView(padding:const EdgeInsets.fromLTRB(16,12,16,24),child:child);}
class SectionTitle extends StatelessWidget {final String title,sub;const SectionTitle(this.title,{this.sub='',super.key});@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.only(bottom:12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900,color:ink)),if(sub.isNotEmpty)Text(sub,style:const TextStyle(color:muted,fontSize:12))]));}
class SoftCard extends StatelessWidget {final Widget child;final EdgeInsets padding;const SoftCard({super.key,required this.child,this.padding=const EdgeInsets.all(15)});@override Widget build(BuildContext c)=>Card(child:Padding(padding:padding,child:child));}

class IslandPage extends StatelessWidget {
 final IslandState state;final VoidCallback onTasks;const IslandPage({super.key,required this.state,required this.onTasks});
 @override Widget build(BuildContext context){
  final pets=state.owned.reversed.take(24).map((id)=>state.pets.where((p)=>p.id==id).firstOrNull).whereType<Pet>().toList();
  final pct=state.tasks.isEmpty?0:state.completed/state.tasks.length;
  return PagePad(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   Row(children:[const Expanded(child:SectionTitle('今天的小島','慢慢完成任務，讓島上住進更多夥伴。')),Text('${state.completed}/${state.tasks.length} 完成',style:const TextStyle(color:darkGreen,fontWeight:FontWeight.bold))]),
   SoftCard(padding:EdgeInsets.zero,child:ClipRRect(borderRadius:BorderRadius.circular(22),child:Container(height:340,decoration:const BoxDecoration(gradient:LinearGradient(colors:[Color(0xFFB7E6F2),Color(0xFFDAF3D9)],begin:Alignment.topCenter,end:Alignment.bottomCenter)),child:Stack(children:[
    Positioned(left:18,right:18,top:45,bottom:35,child:CustomPaint(painter:IslandPainter())),
    const Positioned(top:18,left:22,child:Text('☁️',style:TextStyle(fontSize:34))),
    const Positioned(top:55,right:35,child:Text('☀️',style:TextStyle(fontSize:34))),
    ...List.generate(pets.length,(i)=>Positioned(left:20+(i*67)%270,top:110+(i*43)%150,child:Column(children:[Text(pets[i].emoji,style:const TextStyle(fontSize:30)),Container(width:34,height:5,decoration:BoxDecoration(color:Colors.black.withOpacity(.12),borderRadius:BorderRadius.circular(8)))]))),
    if(pets.isEmpty)const Positioned.fill(child:Center(child:Text('🌱\\n島上還很空曠，去扭蛋邀請第一位居民吧！',textAlign:TextAlign.center,style:TextStyle(fontWeight:FontWeight.bold,height:1.7)))),
    Positioned(left:12,bottom:12,child:Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),decoration:BoxDecoration(color:Colors.white.withOpacity(.85),borderRadius:BorderRadius.circular(20)),child:Text('🏡 居民 ${state.owned.length} 位',style:const TextStyle(fontWeight:FontWeight.bold,color:ink)))),
   ])))),
   const SizedBox(height:14),
   SoftCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('今日任務進度',style:TextStyle(fontWeight:FontWeight.w900)),Text('${(pct*100).round()}%',style:const TextStyle(color:darkGreen,fontWeight:FontWeight.w900))]),const SizedBox(height:10),ClipRRect(borderRadius:BorderRadius.circular(20),child:LinearProgressIndicator(value:pct,minHeight:10,backgroundColor:const Color(0xFFEAF0E9),color:green)),const SizedBox(height:12),FilledButton.icon(onPressed:onTasks,icon:const Icon(Icons.task_alt),label:const Text('去完成任務'))])),
   const SizedBox(height:10),const Text('島民小語',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),const SizedBox(height:8),
   if(pets.isNotEmpty)SoftCard(child:Text('${pets.first.emoji}  ${pets.first.quote}',style:const TextStyle(fontWeight:FontWeight.bold))),
  ]));
 }
}
class IslandPainter extends CustomPainter {
 @override void paint(Canvas canvas,Size size){
  final p=Paint()..color=const Color(0xFF75C98D);
  final path=Path()..moveTo(size.width*.08,size.height*.48)..cubicTo(size.width*.02,size.height*.12,size.width*.34,size.height*.02,size.width*.52,size.height*.10)..cubicTo(size.width*.88,size.height*.02,size.width*.98,size.height*.30,size.width*.92,size.height*.58)..cubicTo(size.width*.88,size.height*.92,size.width*.58,size.height*.96,size.width*.38,size.height*.88)..cubicTo(size.width*.12,size.height*.98,size.width*.02,size.height*.72,size.width*.08,size.height*.48)..close();
  canvas.drawShadow(path,Colors.black.withOpacity(.16),8,true);canvas.drawPath(path,p);
  final path2=Path()..addOval(Rect.fromLTWH(size.width*.58,size.height*.52,size.width*.22,size.height*.18));canvas.drawPath(path2,Paint()..color=const Color(0xFF79CDE0));
  for(int i=0;i<7;i++){final x=size.width*(.17+(i%4)*.19),y=size.height*(.23+(i%3)*.19);canvas.drawCircle(Offset(x,y),10,Paint()..color=const Color(0xFF4EAB72));canvas.drawRect(Rect.fromLTWH(x-2,y+6,4,12),Paint()..color=const Color(0xFF9B714B));}
 }
 @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>false;
}

class TasksPage extends StatelessWidget {
 final IslandState state;const TasksPage({super.key,required this.state});
 @override Widget build(BuildContext context)=>PagePad(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
  const SectionTitle('每日任務',sub:'不需要證明給任何人看，完成就給自己一枚勾勾。'),
  SoftCard(child:Row(children:[Expanded(child:Text('完成 ${state.completed} / ${state.tasks.length} 項',style:const TextStyle(fontWeight:FontWeight.w900))),Text('🪙 ${state.coins}',style:const TextStyle(fontWeight:FontWeight.w900,color:darkGreen))])),
  ...state.tasks.map((t)=>TaskTile(task:t,state:state)),
  const SizedBox(height:8),
  FilledButton.icon(onPressed:()=>showTaskDialog(context,state),icon:const Icon(Icons.add),label:const Text('新增任務')),
 ]));
}
class TaskTile extends StatelessWidget {
 final HabitTask task;final IslandState state;const TaskTile({super.key,required this.task,required this.state});
 @override Widget build(BuildContext c)=>SoftCard(child:Column(children:[
  Row(children:[Checkbox(value:task.done,onChanged:(v)=>state.complete(task,v??false)),Expanded(child:Text(task.name,style:TextStyle(fontWeight:FontWeight.w800,decoration:task.done?TextDecoration.lineThrough:null))),Text('+${task.reward} 🪙',style:const TextStyle(color:darkGreen,fontWeight:FontWeight.bold))]),
  if(task.type!='check')Row(children:[Expanded(child:Text('${task.progress.toStringAsFixed(0)} / ${task.target.toStringAsFixed(0)} ${task.type=='minutes'?'分鐘':task.type=='km'?'公里':'次'}',style:const TextStyle(color:muted,fontSize:12))),TextButton(onPressed:()=>showProgressDialog(c,task,state),child:const Text('更新進度'))]),
  if(task.app.isNotEmpty)Align(alignment:Alignment.centerLeft,child:Text('📱 ${task.app}',style:const TextStyle(color:muted,fontSize:12))),
 ]));
}
Future<void> showProgressDialog(BuildContext c,HabitTask t,IslandState s)async{
 final ctl=TextEditingController(text:t.progress.toStringAsFixed(0));
 await showDialog(context:c,builder:(_)=>AlertDialog(title:Text('更新：${t.name}'),content:TextField(controller:ctl,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'目前累積進度')),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('取消')),FilledButton(onPressed:(){s.updateProgress(t,double.tryParse(ctl.text)??0);Navigator.pop(c);},child:const Text('儲存'))]));
}
Future<void> showTaskDialog(BuildContext c,IslandState s)async{
 final name=TextEditingController(),target=TextEditingController(text:'1'),app=TextEditingController(),link=TextEditingController();String type='check';int reward=1;
 await showDialog(context:c,builder:(_)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:const Text('新增每日任務'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
  TextField(controller:name,decoration:const InputDecoration(labelText:'任務名稱')),
  const SizedBox(height:8),DropdownButtonFormField(value:type,decoration:const InputDecoration(labelText:'任務類型'),items:const [DropdownMenuItem(value:'check',child:Text('直接打勾')),DropdownMenuItem(value:'minutes',child:Text('時長（分鐘）')),DropdownMenuItem(value:'count',child:Text('次數')),DropdownMenuItem(value:'km',child:Text('距離（公里）'))],onChanged:(v)=>set(()=>type=v??'check')),
  TextField(controller:target,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'目標值')),
  TextField(controller:app,decoration:const InputDecoration(labelText:'關聯 App（選填）')),
  TextField(controller:link,decoration:const InputDecoration(labelText:'連結（選填）')),
  DropdownButtonFormField<int>(value:reward,decoration:const InputDecoration(labelText:'完成獎勵'),items:[1,2,3].map((v)=>DropdownMenuItem(value:v,child:Text('$v 枚代幣'))).toList(),onChanged:(v)=>set(()=>reward=v??1)),
 ])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('取消')),FilledButton(onPressed:(){if(name.text.trim().isNotEmpty){s.addTask(name.text.trim(),type,double.tryParse(target.text)??1,reward,app.text.trim(),link.text.trim());Navigator.pop(c);}},child:const Text('建立'))])));
}

class GachaPage extends StatelessWidget {
 final IslandState state;final ValueChanged<Pet> onDraw;const GachaPage({super.key,required this.state,required this.onDraw});
 @override Widget build(BuildContext c)=>PagePad(child:Column(children:[
  const SectionTitle('扭蛋屋',sub:'未知的蛋裡，住著下一位島民。'),
  SoftCard(child:Column(children:[const Text('🥚',style:TextStyle(fontSize:100)),const Text('今日扭蛋池',style:TextStyle(fontWeight:FontWeight.w900,fontSize:20)),const SizedBox(height:8),const Text('普通 70%　稀有 25%　傳說 5%',style:TextStyle(color:muted)),const SizedBox(height:12),Text('每次需要 ${state.gachaCost} 枚代幣',style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:14),FilledButton.icon(onPressed:(){final p=state.draw();if(p==null){ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('代幣不足，先去完成任務吧！')));}else{onDraw(p);showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('新島民報到！'),content:Column(mainAxisSize:MainAxisSize.min,children:[Text(p.emoji,style:const TextStyle(fontSize:76)),Text(p.name,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text(['普通','稀有','傳說'][p.rarity]),Text('「${p.quote}」')]),actions:[FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('歡迎加入'))]));}},icon:const Icon(Icons.casino),label:const Text('抽一顆扭蛋'))])),
  const SizedBox(height:12),const Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[Text('🟢 普通 70%'),Text('🔵 稀有 25%'),Text('🟣 傳說 5%')]),
 ]));
}

class CollectionPage extends StatelessWidget {
 final IslandState state;const CollectionPage({super.key,required this.state});
 @override Widget build(BuildContext c){
  final pets=state.pets;
  return PagePad(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   const SectionTitle('動物圖鑑',sub:'每一位島民，都有自己的小故事。'),
   SoftCard(child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('收集進度',style:TextStyle(fontWeight:FontWeight.w900)),Text('${pets.where((p)=>state.count(p.id)>0).length}/${pets.length}',style:const TextStyle(color:darkGreen,fontWeight:FontWeight.w900))])),
   GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,childAspectRatio:.88,crossAxisSpacing:9,mainAxisSpacing:9),itemCount:pets.length,itemBuilder:(_,i){final p=pets[i],n=state.count(p.id);return Container(decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0xFFE7EEE6))),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(n>0?p.emoji:'❔',style:const TextStyle(fontSize:34)),Text(n>0?p.name:'未解鎖',style:const TextStyle(fontWeight:FontWeight.bold)),Text(n>1?'×$n':['普通','稀有','傳說'][p.rarity],style:const TextStyle(color:muted,fontSize:11))]));}),
  ]));
 }
}

class ProfilePage extends StatelessWidget {
 final IslandState state;final AuthService auth;final bool firebaseReady;final ValueChanged<String> onMessage;
 const ProfilePage({super.key,required this.state,required this.auth,required this.firebaseReady,required this.onMessage});
 @override Widget build(BuildContext c){
  final user=auth.user;
  return PagePad(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   const SectionTitle('我的小島帳號',sub:'資料先存在本機；登入後可同步到雲端。'),
   SoftCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(children:[const CircleAvatar(radius:27,backgroundColor:Color(0xFFE5F5E9),child:Icon(Icons.person,color:darkGreen,size:30)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(user?.displayName??'島主訪客',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:17)),Text(user?.email??'尚未登入',style:const TextStyle(color:muted,fontSize:12))]))]),
    const SizedBox(height:14),
    if(user==null)...[
      FilledButton.icon(onPressed:!firebaseReady?null:()async{try{await auth.google();await auth.restore(state);await state.save();await auth.sync(state);onMessage('Google 登入成功，資料已同步');}catch(e){onMessage('Google 登入失敗：$e');}},icon:const Icon(Icons.g_mobiledata),label:const Text('使用 Google 登入')),
      const SizedBox(height:8),
      OutlinedButton.icon(onPressed:!firebaseReady?null:()async{try{await auth.apple();await auth.restore(state);await state.save();await auth.sync(state);onMessage('Apple 登入成功，資料已同步');}catch(e){onMessage('Apple 登入失敗：$e');}},icon:const Icon(Icons.apple),label:const Text('使用 Apple 登入')),
      if(!firebaseReady)const Padding(padding:EdgeInsets.only(top:8),child:Text('尚未連接 Firebase。完成專案設定後即可啟用登入。',style:TextStyle(color:muted,fontSize:12))),
    ]else...[
      FilledButton(onPressed:()async{try{await auth.sync(state);onMessage('雲端同步完成');}catch(e){onMessage('同步失敗：$e');}},child:const Text('立即同步資料')),
      OutlinedButton(onPressed:()async{await auth.signOut();onMessage('已登出');},child:const Text('登出')),
    ]
   ])),
   const SizedBox(height:10),
   const Text('遊戲設定',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),
   SoftCard(child:Column(children:[
    SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('深色模式'),value:state.dark,onChanged:(v){state.dark=v;state.save();}),
    ListTile(contentPadding:EdgeInsets.zero,title:const Text('代幣上限'),subtitle:Text('目前 ${state.coinCap} 枚'),trailing:const Icon(Icons.edit),onTap:()async{final x=TextEditingController(text:'${state.coinCap}');await showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('設定代幣上限'),content:TextField(controller:x,keyboardType:TextInputType.number),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('取消')),FilledButton(onPressed:(){state.coinCap=max(1,int.tryParse(x.text)??20);state.coins=min(state.coins,state.coinCap);state.save();Navigator.pop(c);},child:const Text('儲存'))]));}),
    ListTile(contentPadding:EdgeInsets.zero,title:const Text('每次扭蛋花費'),subtitle:Text('${state.gachaCost} 枚'),trailing:const Icon(Icons.edit),onTap:()async{final x=TextEditingController(text:'${state.gachaCost}');await showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('設定扭蛋花費'),content:TextField(controller:x,keyboardType:TextInputType.number),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('取消')),FilledButton(onPressed:(){state.gachaCost=max(1,int.tryParse(x.text)??5);state.save();Navigator.pop(c);},child:const Text('儲存'))]));}),
   ])),
   const SizedBox(height:10),const Text('設計工作室',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),
   SoftCard(child:Column(children:[
    FilledButton.icon(onPressed:()=>showPetDialog(c,state),icon:const Icon(Icons.add_reaction),label:const Text('設計專屬動物')),
    const Text('自訂動物會加入你的個人扭蛋池。',style:TextStyle(color:muted,fontSize:12)),
   ])),
   const SizedBox(height:12),const Text('隱私與資料',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),
   SoftCard(child:const Text('目前版本以私人島嶼為主，不提供公開個人頁面或島嶼互訪。任務證明不會自動上傳。雲端同步僅儲存遊戲資料。',style:TextStyle(color:muted,height:1.5))),
  ]));
 }
}
Future<void> showPetDialog(BuildContext c,IslandState s)async{
 final emoji=TextEditingController(text:'🐙'),name=TextEditingController(),quote=TextEditingController();int rarity=0;
 await showDialog(context:c,builder:(_)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:const Text('設計你的島民'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
  TextField(controller:emoji,decoration:const InputDecoration(labelText:'表情符號')),
  TextField(controller:name,decoration:const InputDecoration(labelText:'名字')),
  TextField(controller:quote,decoration:const InputDecoration(labelText:'口頭禪')),
  DropdownButtonFormField(value:rarity,items:const [DropdownMenuItem(value:0,child:Text('普通')),DropdownMenuItem(value:1,child:Text('稀有')),DropdownMenuItem(value:2,child:Text('傳說'))],onChanged:(v)=>set(()=>rarity=v??0)),
 ])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('取消')),FilledButton(onPressed:(){if(emoji.text.trim().isNotEmpty&&name.text.trim().isNotEmpty){s.addPet(emoji.text.trim(),name.text.trim(),rarity,quote.text.trim());Navigator.pop(c);}},child:const Text('加入扭蛋池'))])));
}
