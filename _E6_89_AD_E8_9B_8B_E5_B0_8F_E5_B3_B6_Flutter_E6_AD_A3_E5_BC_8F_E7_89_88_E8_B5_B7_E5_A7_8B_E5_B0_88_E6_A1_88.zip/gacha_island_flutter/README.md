# 扭蛋小島 Flutter 專案

這是一個可繼續開發的 iOS / Android Flutter 原始碼起始專案，採用「私人島嶼」方向。

## 已包含
- 2D 俯視風格島嶼首頁（Flutter CustomPainter 繪製）
- 每日任務：打勾、時長／次數／距離進度、自訂任務與獎勵
- 扭蛋：普通 70%、稀有 25%、傳說 5%
- 動物圖鑑、重複收藏、自訂動物
- 本機資料保存（SharedPreferences）
- Firebase Auth 的 Google / Apple 登入程式流程
- Firestore 使用者資料同步程式流程
- 深色模式、代幣上限與抽卡花費設定

## 重要：目前不是可直接上架的成品
此套原始碼已搭好主要畫面與功能骨架，但 Google / Apple 登入和雲端同步需要你自己的 Firebase 專案與平台憑證。未設定時，遊戲仍可在本機模式使用。這裡沒有替你建立 Firebase 專案，也沒有你的 Apple Developer / Google Play 開發者憑證。

## 開發環境
- Flutter stable（建議使用目前穩定版）
- Android Studio / Xcode
- iOS 真機建置需要 macOS + Xcode
- Android 可在 Windows / macOS / Linux 建置

## 啟動
```bash
flutter create . --platforms=android,ios
flutter pub get
flutter run
```

若 `flutter create .` 詢問覆寫檔案，保留本專案的 `pubspec.yaml` 和 `lib/main.dart`。

## 啟用 Firebase
1. 建立 Firebase project。
2. 在 Firebase Console 加入 Android 與 iOS App，套用正確的 package/bundle ID。
3. 安裝 FlutterFire CLI，執行：
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
4. 依 FlutterFire 產生的 `firebase_options.dart`，把 `main()` 的初始化改成：
   ```dart
   await Firebase.initializeApp(
     options: DefaultFirebaseOptions.currentPlatform,
   );
   ```
   並加入：
   ```dart
   import 'firebase_options.dart';
   ```
5. 在 Firebase Authentication 啟用 Google 與 Apple provider。
6. Google：設定 Android SHA-1/SHA-256、OAuth client IDs、iOS URL scheme。
7. Apple：在 Apple Developer 設定 Sign in with Apple capability、Service ID / key 等必要項目，並在 Xcode Runner target 開啟 Sign in with Apple capability。Android 端使用 Firebase 的 Apple OAuth 瀏覽器流程，需完成 Firebase Apple provider 與回呼網域設定。
8. 在 Firestore 建立資料庫，設定安全規則，禁止使用者讀寫其他人的 `users/{uid}` 文件。

建議的基本 Firestore rules（部署前仍需依實際資料結構檢查）：
```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

## 發布前必做
- 修正並確認 Android applicationId / iOS bundle identifier。
- 完成 Google / Apple OAuth 設定與真機測試。
- 補上隱私權政策、服務條款、帳號刪除流程。
- 測試斷網、換機、登出、帳號合併與雲端同步衝突。
- 加入 Firestore 安全規則、App Store 隱私標籤及 Google Play Data safety。
- 目前扭蛋機率為客戶端示範邏輯；正式多人環境建議改由 Cloud Functions 伺服器端抽卡並記錄結果，避免客戶端竄改。
- 目前雲端同步採簡化覆寫策略，尚未做多裝置衝突合併。

## 專案限制與下一步
- 外部 App（健康、語言學習）目前只是任務備註欄位，尚未串接 Apple Health、Health Connect 或各 App API。
- 社群功能依照目前方向保持關閉。
- 本版沒有廣告、付費、好友、公開島嶼功能。
- 需在實際 Flutter / Xcode / Android Studio 環境執行編譯與真機測試；本交付環境沒有完成 iOS/Android 編譯。
